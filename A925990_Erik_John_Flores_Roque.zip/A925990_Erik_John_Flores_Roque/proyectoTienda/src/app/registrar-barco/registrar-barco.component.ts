import { Component, OnInit } from '@angular/core';
import { Barco } from '../barco';
import { BarcoService } from '../barco.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-registrar-barco',
  templateUrl: './registrar-barco.component.html',
  styleUrls: ['./registrar-barco.component.css']
})
export class RegistrarBarcoComponent implements OnInit {
  formularioBarco: FormGroup;
  barco : Barco = new Barco();

  constructor(private barcoServicio: BarcoService, private router: Router) { }

  ngOnInit(): void {
    this.formularioBarco = new FormGroup({
      nombre: new FormControl('', [Validators.required]),
      matricula: new FormControl('', [Validators.required]),
      amarre: new FormControl('', [Validators.required])
    });
  }
  // Guardar nuevo barco
  guardarBarco() {
    this.barcoServicio.registrarBarco(this.barco).subscribe(
      dato => {
        console.log(dato);
        this.irALaListaDeBarcos();
      },
      error => console.log(error)
    );
  }
  // Volver a la lista de barcos
  irALaListaDeBarcos() {
    this.router.navigate(['/barcos']);
  }

  onSubmit() {
    this.guardarBarco();
  }
}
