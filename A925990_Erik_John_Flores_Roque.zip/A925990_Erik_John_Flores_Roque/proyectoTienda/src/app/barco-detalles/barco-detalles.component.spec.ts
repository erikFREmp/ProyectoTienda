import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BarcoDetallesComponent } from './barco-detalles.component';

describe('BarcoDetallesComponent', () => {
  let component: BarcoDetallesComponent;
  let fixture: ComponentFixture<BarcoDetallesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [BarcoDetallesComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(BarcoDetallesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
