import { Component, OnInit } from '@angular/core';
import { Barco } from '../barco';
import { ActivatedRoute } from '@angular/router';
import { BarcoService } from '../barco.service';

@Component({
  selector: 'app-barco-detalles',
  templateUrl: './barco-detalles.component.html',
  styleUrl: './barco-detalles.component.css'
})
export class BarcoDetallesComponent implements OnInit {
  // Declaración de variables
  id:number;
  barco:Barco;
  constructor(private route:ActivatedRoute, private barcoServicio:BarcoService) { }
  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
    this.barco = new Barco();
    this.barcoServicio.obtenerBarcoPorId(this.id).subscribe(dato => {
      this.barco = dato;
    }, error => console.log(error));
  }

}
