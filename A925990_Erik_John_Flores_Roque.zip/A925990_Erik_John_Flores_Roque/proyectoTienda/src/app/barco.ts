export class Barco {
    
    id: number; 
    matricula: string;
    nombre : string;
    numAmarre : number;
}
