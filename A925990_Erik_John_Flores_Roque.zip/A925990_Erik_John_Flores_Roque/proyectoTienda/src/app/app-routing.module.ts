import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ListaBarcosComponent } from './lista-barcos/lista-barcos.component';
import { RegistrarBarcoComponent } from './registrar-barco/registrar-barco.component';
import { ActualizarBarcoComponent } from './actualizar-barco/actualizar-barco.component';
import { BarcoDetallesComponent } from './barco-detalles/barco-detalles.component';

const routes: Routes = [
  {path: 'barcos', component:ListaBarcosComponent},
  {path: '', redirectTo: 'barcos', pathMatch: 'full'},
  {path: 'registrar-barco', component: RegistrarBarcoComponent},
  {path: 'actualizar-barco/:id', component: ActualizarBarcoComponent},
  {path: 'barco-detalles/:id', component: BarcoDetallesComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
