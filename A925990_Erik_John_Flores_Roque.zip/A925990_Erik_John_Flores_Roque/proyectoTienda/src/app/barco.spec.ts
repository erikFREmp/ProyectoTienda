import { Barco } from './barco';

describe('Barco', () => {
  it('should create an instance', () => {
    expect(new Barco()).toBeTruthy();
  });
});
