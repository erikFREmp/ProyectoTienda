import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Barco } from './barco';

@Injectable({
  providedIn: 'root'
})
export class BarcoService {
  // Url obtiene el listado de todos los barcos en el backend 
  private baseURL = 'http://localhost:8080/barcos/barco';

  constructor(private httpClient : HttpClient) { }
  // Metodo que nos da los empleados
  obtenerListadeBarcos():Observable<Barco[]>{
    return this.httpClient.get<Barco[]>(`${this.baseURL}`);
  }
  // Metodo para registrar un barco
  registrarBarco(barco : Barco):Observable<Object>{
    return this.httpClient.post(`${this.baseURL}`,barco);
  }

  actualizarBarco(id:number,barco:Barco):Observable<Object>{
    console.log("BARCO",barco)
    return this.httpClient.put(this.baseURL,barco);
  }
  obtenerBarcoPorId(id:number):Observable<Barco>{
    return this.httpClient.get<Barco>(`${this.baseURL}/${id}`);
  }
  eliminarBarco(id:number):Observable<Object>{
    return this.httpClient.delete(`${this.baseURL}/${id}`);
  }

}
