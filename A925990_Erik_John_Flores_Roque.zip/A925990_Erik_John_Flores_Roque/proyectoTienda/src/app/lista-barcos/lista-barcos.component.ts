import { Component, OnInit } from '@angular/core';
import { Barco } from '../barco';
import { BarcoService } from '../barco.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-lista-barcos',
  templateUrl: './lista-barcos.component.html',
  styleUrl: './lista-barcos.component.css'
})
export class ListaBarcosComponent implements OnInit {
  
  barcos : Barco[] = [];
  constructor(private barcoServicio:BarcoService, private router:Router) { }
  ngOnInit(): void {
    this.obtenerBarcos();
  }
  // Función boton actualizar un barco
  actualizarBarco(id:number){
    this.router.navigate(['actualizar-barco',id]);
  }
  // Función de eliminar un barco con alerta incluida
  eliminarBarco(id:number){
    Swal.fire({
      title: "Eliminar?",
      text: "¿Estas seguro de eliminar el barco?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      cancelButtonText: "No, me lo pense mejor",
      confirmButtonText: "Si, estoy seguro"
    }).then((result) => {
      if (result.value) {
        this.barcoServicio.eliminarBarco(id).subscribe(dato=>{
          console.log(dato);
          this.obtenerBarcos();
          Swal.fire(
      'Barco eliminado'
      )
        });
      }
    });
    }	
  // Declaramos obtenerBarcos
  private obtenerBarcos(){
    this.barcoServicio.obtenerListadeBarcos().subscribe(dato =>{
      this.barcos = dato;
    });
  }
  // Funcionalidad boton para ver mas detalles de un barco
  verDetallesBarcos(id:number){
    this.router.navigate(['barco-detalles',id]);
  }
}
