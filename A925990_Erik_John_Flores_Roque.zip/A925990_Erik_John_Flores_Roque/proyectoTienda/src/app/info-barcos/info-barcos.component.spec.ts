import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InfoBarcosComponent } from './info-barcos.component';

describe('InfoBarcosComponent', () => {
  let component: InfoBarcosComponent;
  let fixture: ComponentFixture<InfoBarcosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [InfoBarcosComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(InfoBarcosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
