import { Component } from '@angular/core';

@Component({
  selector: 'app-info-barcos',
  templateUrl: './info-barcos.component.html',
  styleUrl: './info-barcos.component.css'
})
export class InfoBarcosComponent {

}
