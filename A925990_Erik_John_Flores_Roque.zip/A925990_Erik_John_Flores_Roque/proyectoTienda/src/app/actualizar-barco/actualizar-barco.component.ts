import { Component, OnInit } from '@angular/core';
import { Barco } from '../barco';
import { ActivatedRoute, Router } from '@angular/router';
import { BarcoService } from '../barco.service';

@Component({
  selector: 'app-actualizar-barco',
  templateUrl: './actualizar-barco.component.html',
  styleUrl: './actualizar-barco.component.css'
})
export class ActualizarBarcoComponent implements OnInit {
  
  id:number;
  barco:Barco = new Barco();
  constructor(private barcoService:BarcoService, private router:Router, private route:ActivatedRoute) {}

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
    this.barcoService.obtenerBarcoPorId(this.id).subscribe(dato => {
      this.barco = dato;
    }, error => console.log(error));
  }
  // Función para volver a la lista de barcos
  irALaListaDeBarcos(){
    this.router.navigate(['/barcos']);
    alert(`Barco actualizado: ${this.barco.nombre}`);
  }
  // Funcion que sucede al darle al boton de actualizar barco
  onSubmit(){
    this.barcoService.actualizarBarco(this.id, this.barco).subscribe(dato => {
      this.irALaListaDeBarcos();
    }, error => console.log(error));
  }
}
