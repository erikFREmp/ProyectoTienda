package com.barcos.barco.service;

import com.barcos.barco.entity.Patron;
import com.barcos.barco.exception.ResourceFoundException;
import com.barcos.barco.repository.PatronRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class PatronServiceImplTest {

    @Mock
    private PatronRepository patronRepository;

    @InjectMocks
    private PatronServiceImpl patronService;

    private Patron patron;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        patron = new Patron();
        patron.setId(1);
        patron.setNombre("John");
        patron.setApellidos("Doe");
        patron.setTelefono(123456789);
    }

    @Test
    void save() {
        when(patronRepository.save(patron)).thenReturn(patron);
        Patron savedPatron = patronService.save(patron);
        assertEquals(patron, savedPatron);
        verify(patronRepository).save(patron);
    }

    @Test
    void findById_existingId_returnPatron() {

        when(patronRepository.findById(1)).thenReturn(Optional.of(patron));


        Patron foundPatron = patronService.findById(1);


        assertEquals(patron, foundPatron);
        verify(patronRepository).findById(1);
    }

    @Test
    void findById_nonExistingId_throwException() {

        when(patronRepository.findById(1)).thenReturn(Optional.empty());


        assertThrows(ResourceFoundException.class, () -> patronService.findById(1));
    }

    @Test
    void deleteById() {

        patronService.deleteById(1);


        verify(patronRepository).deleteById(1);
    }

    @Test
    void update() {

        when(patronRepository.save(patron)).thenReturn(patron);


        Patron updatedPatron = patronService.update(patron);


        assertEquals(patron, updatedPatron);
        verify(patronRepository).save(patron);
    }
}
