package com.barcos.barco.service;

import com.barcos.barco.entity.Salida;
import com.barcos.barco.exception.ResourceFoundException;
import com.barcos.barco.repository.SalidaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class SalidaServiceImplTest {

    @Mock
    private SalidaRepository salidaRepository;

    @InjectMocks
    private SalidaServiceImpl salidaService;

    private Salida salida;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        salida = new Salida();
        salida.getIdSalida();
        // Configura cualquier otro atributo que necesites para las pruebas
    }

    @Test
    void save() {
        when(salidaRepository.save(salida)).thenReturn(salida);
        Salida savedSalida = salidaService.save(salida);
        assertEquals(salida, savedSalida);
        verify(salidaRepository).save(salida);
    }

    @Test
    void findById_existingId_returnSalida() {
        // Simula el comportamiento del repositorio devolviendo una salida con ID 1
        when(salidaRepository.findById(1)).thenReturn(Optional.of(salida));

        // Llama al método del servicio
        Salida foundSalida = salidaService.findById(1);

        // Verifica que se devolvió la salida correcta
        assertEquals(salida, foundSalida);
        verify(salidaRepository).findById(1);
    }

    @Test
    void findById_nonExistingId_throwException() {
        // Simula el comportamiento del repositorio devolviendo un optional vacío
        when(salidaRepository.findById(1)).thenReturn(Optional.empty());

        // Llama al método del servicio y verifica que lance la excepción esperada
        assertThrows(ResourceFoundException.class, () -> salidaService.findById(1));
    }

    @Test
    void deleteById() {
        // Llama al método del servicio para eliminar una salida por ID
        salidaService.deleteById(1);

        // Verifica que se llamó al método deleteById del repositorio con el ID correcto
        verify(salidaRepository).deleteById(1);
    }

    @Test
    void update() {
        // Simula el comportamiento del repositorio guardando la salida
        when(salidaRepository.save(salida)).thenReturn(salida);

        // Llama al método del servicio para actualizar la salida
        Salida updatedSalida = salidaService.update(salida);

        // Verifica que se devolvió la salida correcta después de la actualización
        assertEquals(salida, updatedSalida);
        verify(salidaRepository).save(salida);
    }
}
