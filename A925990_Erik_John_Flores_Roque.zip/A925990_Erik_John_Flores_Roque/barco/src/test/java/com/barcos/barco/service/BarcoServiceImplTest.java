package com.barcos.barco.service;

import com.barcos.barco.entity.Barco;
import com.barcos.barco.repository.BarcoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class BarcoServiceImplTest {
    @Mock
    private BarcoRepository barcoRepository;
    @InjectMocks
    private BarcoServiceImpl barcoService;
    private Barco barco;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        barco = new Barco();
        barco.setId(1);
        barco.setIdSocio(1);
        barco.setMatricula(String.valueOf(1));
    }

    @Test
    void save() {
        when(barcoRepository.save(barco)).thenReturn(barco);
        Barco savedBarco = barcoService.save(barco);
        assertEquals(1, savedBarco.getId());
        assertEquals(1, savedBarco.getIdSocio());
        assertEquals(String.valueOf(1), savedBarco.getMatricula());

        verify(barcoRepository).save(barco);
    }

    @Test
    void findAll() {
        when(barcoRepository.findAll()).thenReturn(Arrays.asList(barco));
        List<Barco> barcos = barcoService.findAll();
        verify(barcoRepository).findAll();
        assertEquals(1,barcos.size());
    }

    @Test
    void findById() {
        // Configuración del comportamiento del repositorio mock
        when(barcoRepository.findById(1)).thenReturn(Optional.of(barco));

        // Llamada al método findById del servicio con el ID de prueba
        Barco foundBarco = barcoService.findById(1);

        // Verificación de que se obtuvo el objeto de prueba correctamente
        assertEquals(1, foundBarco.getId());
        assertEquals(1, foundBarco.getIdSocio());
        assertEquals(String.valueOf(1), foundBarco.getMatricula());

        // Verificación de que el método findById del repositorio fue llamado una vez con el ID de prueba
        verify(barcoRepository).findById(1);
    }



    @Test
    void deleteById() {
        barcoService.deleteById(1);
        verify(barcoRepository).deleteById(1);
    }

    @Test
    void update() {
        when(barcoRepository.save(barco)).thenReturn(barco);
        Barco updatedBarco = barcoService.update(barco);
        assertEquals(1, updatedBarco.getId());
        assertEquals(1, updatedBarco.getIdSocio());
        assertEquals(String.valueOf(1), updatedBarco.getMatricula());
        verify(barcoRepository).save(barco);
    }
}