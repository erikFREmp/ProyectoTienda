package com.barcos.barco.service;

import com.barcos.barco.entity.Socio;
import com.barcos.barco.exception.ResourceFoundException;
import com.barcos.barco.repository.SocioRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class SocioServiceImplTest {

    @Mock
    private SocioRepository socioRepository;

    @InjectMocks
    private SocioServiceImpl socioService;

    private Socio socio;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        socio = new Socio();
        socio.setId(1);
        socio.setNombre("NombreSocio");
        // Configura cualquier otro atributo que necesites para las pruebas
    }

    @Test
    void save() {
        when(socioRepository.save(socio)).thenReturn(socio);
        Socio savedSocio = socioService.save(socio);
        assertEquals(socio, savedSocio);
        verify(socioRepository).save(socio);
    }

    @Test
    void findById_existingId_returnSocio() {
        // Simula el comportamiento del repositorio devolviendo un socio con ID 1
        when(socioRepository.findById(1)).thenReturn(Optional.of(socio));

        // Llama al método del servicio
        Socio foundSocio = socioService.findById(1);

        // Verifica que se devolvió el socio correcto
        assertEquals(socio, foundSocio);
        verify(socioRepository).findById(1);
    }

    @Test
    void findById_nonExistingId_throwException() {
        // Simula el comportamiento del repositorio devolviendo un optional vacío
        when(socioRepository.findById(1)).thenReturn(Optional.empty());

        // Llama al método del servicio y verifica que lance la excepción esperada
        assertThrows(ResourceFoundException.class, () -> socioService.findById(1));
    }

    @Test
    void deleteById() {
        // Llama al método del servicio para eliminar un socio por ID
        socioService.deleteById(1);

        // Verifica que se llamó al método deleteById del repositorio con el ID correcto
        verify(socioRepository).deleteById(1);
    }

    @Test
    void update() {
        // Simula el comportamiento del repositorio guardando el socio
        when(socioRepository.save(socio)).thenReturn(socio);

        // Llama al método del servicio para actualizar el socio
        Socio updatedSocio = socioService.update(socio);

        // Verifica que se devolvió el socio correcto después de la actualización
        assertEquals(socio, updatedSocio);
        verify(socioRepository).save(socio);
    }
}
