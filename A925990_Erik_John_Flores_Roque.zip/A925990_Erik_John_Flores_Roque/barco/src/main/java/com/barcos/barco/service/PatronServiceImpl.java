package com.barcos.barco.service;
import com.barcos.barco.entity.Barco;
import com.barcos.barco.exception.ResourceFoundException;
import com.barcos.barco.entity.Patron;
import com.barcos.barco.repository.PatronRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PatronServiceImpl implements PatronService {
    private final PatronRepository patronRepository;

    public PatronServiceImpl(PatronRepository patronRepository) {
        this.patronRepository = patronRepository;
    }

    @Override
    public Patron save(Patron patron) {
        return patronRepository.save(patron);
    }

    @Override
    public List<Patron> findAll() {
        return patronRepository.findAll();
    }
    @Override
    public Patron findById(Integer id) {
        return patronRepository.findById(id).orElseThrow(
                ResourceFoundException::new
        );
    }

    @Override
    public void deleteById(Integer id) {
        patronRepository.deleteById(id);
    }

    @Override
    public Patron update(Patron patron) {
        return patronRepository.save(patron);
    }
}
