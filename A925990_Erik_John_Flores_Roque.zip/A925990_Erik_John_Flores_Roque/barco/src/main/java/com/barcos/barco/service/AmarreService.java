package com.barcos.barco.service;

import com.barcos.barco.entity.Amarre;

import java.util.List;

public interface AmarreService {
    Amarre save(Amarre amarre);

    List<Amarre> findAll();

    Amarre findById(Integer id);

    void deleteById(Integer id);

    Amarre update(Amarre amarre);
}
