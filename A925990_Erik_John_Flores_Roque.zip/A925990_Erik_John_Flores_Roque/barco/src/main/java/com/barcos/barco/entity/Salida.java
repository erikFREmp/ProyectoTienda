package com.barcos.barco.entity;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table (name = "salida")
public class Salida {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idSalida;
    private Integer idPatron;
    private Integer idBarco;
    private String fecha;
    private String destino;

    public Salida() {
    }

    public Salida(Integer idSalida, Integer idPatron, Integer idBarco, String fecha, String destino) {
        this.idSalida = idSalida;
        this.idPatron = idPatron;
        this.idBarco = idBarco;
        this.fecha = fecha;
        this.destino = destino;
    }

    public Integer getIdSalida() {
        return idSalida;
    }

    public void setIdSalida(Integer idSalida) {
        this.idSalida = idSalida;
    }

    public Integer getIdPatron() {
        return idPatron;
    }

    public void setIdPatron(Integer idPatron) {
        this.idPatron = idPatron;
    }

    public Integer getIdBarco() {
        return idBarco;
    }

    public void setIdBarco(Integer idBarco) {
        this.idBarco = idBarco;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }
}
