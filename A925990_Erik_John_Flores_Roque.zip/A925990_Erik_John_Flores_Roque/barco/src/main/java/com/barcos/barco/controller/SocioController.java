package com.barcos.barco.controller;

import com.barcos.barco.entity.Salida;
import com.barcos.barco.entity.Socio;
import com.barcos.barco.service.SocioService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/barcos/socio")
public class SocioController {
    private final SocioService socioService;

    public SocioController(SocioService socioService) {
        this.socioService = socioService;
    }
    @PostMapping
    public Socio save(@RequestBody Socio socio) {
        return socioService.save(socio);
    }
    @GetMapping
    public List<Socio> findAll(){
        return socioService.findAll();
    }
    @GetMapping("/{id}")
    public Socio findById(@PathVariable Integer id){
        return socioService.findById(id);
    }
    @DeleteMapping("/{id}")
    public void deleteById(@PathVariable Integer id){
        socioService.deleteById(id);
    }
    @PutMapping
    public Socio updateSocio(@RequestBody Socio socio) {
        Socio socioDb = socioService.findById(socio.getId());
        socioDb.setId(socio.getId());
        socioDb.setNombre(socio.getNombre());
        socioDb.setApellidos(socio.getApellidos());
        socioDb.setTelefono(socio.getTelefono());
        return socioService.update(socioDb);
    }
}
