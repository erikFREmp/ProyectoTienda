create database barcos;

--Entrar al SQL de la base de datos creado (barcos)

CREATE TABLE barco (
  id INT AUTO_INCREMENT PRIMARY KEY,
  id_socio INT,
  matricula VARCHAR(255),
  nombre VARCHAR(255),
  num_amarre INT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


INSERT INTO barco (id, id_socio, matricula, nombre, num_amarre) VALUES
(1, NULL, '2323F', 'Barco Galez', 12345),
(2, NULL, '661G4', 'Juan', 123456),
(3, NULL, 'F4545', 'Pedro', 1234)